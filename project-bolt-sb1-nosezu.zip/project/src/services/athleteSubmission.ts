import { AthletePerformance, WaveResult } from '../types';
import { calculatePace, calculateWaveResults } from '../utils/calculations';
import { submitToNetlify } from '../utils/formSubmission';
import { extractNameParts } from '../utils/nameUtils';
import { formatTimeToMinSec } from '../utils/timeFormatters';

export const submitAthletePerformance = async (
  performance: AthletePerformance
): Promise<WaveResult[]> => {
  const { firstName, lastName } = extractNameParts(performance.fullName);
  const swimPacePerKm = calculatePace(
    performance.swimmingDistance,
    performance.swimmingMinutes,
    performance.swimmingSeconds
  );
  
  const runPacePerKm = calculatePace(
    performance.runningDistance,
    performance.runningMinutes,
    performance.runningSeconds
  );

  const waveResults = calculateWaveResults(
    swimPacePerKm,
    runPacePerKm,
    performance.fitnessLevel
  );

  const completedWaves = waveResults.filter(result => 
    result.wave === 1 || (waveResults[result.wave - 2].totalTime <= waveResults[result.wave - 2].cutOffTime)
  ).length;

  // Calculate 200m swim time once
  const swimTime200m = (swimPacePerKm / 5);

  await submitToNetlify({
    firstName,
    lastName,
    club: performance.club,
    email: performance.email,
    swimTime: formatTimeToMinSec(swimTime200m),
    swimPace: waveResults[0].swimPace,
    runPace: waveResults[0].runPace,
    completedWaves,
    fitnessLevel: performance.fitnessLevel,
    performance: {
      runningDistance: performance.runningDistance,
      runningTime: formatTimeToMinSec(performance.runningMinutes * 60 + performance.runningSeconds),
      swimmingDistance: performance.swimmingDistance,
      swimmingTime: formatTimeToMinSec(performance.swimmingMinutes * 60 + performance.swimmingSeconds)
    }
  });

  return waveResults;
};