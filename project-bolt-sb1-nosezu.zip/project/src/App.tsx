import React from 'react';
import BibNumberForm from './components/BibNumberForm';
import PerformanceForm from './components/PerformanceForm';
import ResultsView from './components/ResultsView';
import { useAthleteForm } from './hooks/useAthleteForm';
import { submitAthletePerformance } from './services/athleteSubmission';

export default function App() {
  const {
    step,
    setStep,
    athleteInfo,
    setAthleteInfo,
    performance,
    setPerformance,
    results,
    setResults
  } = useAthleteForm();

  const handleAthleteInfoSubmit = () => {
    setPerformance(prev => ({
      ...prev,
      ...athleteInfo
    }));
    setStep(2);
  };

  const handlePerformanceSubmit = async () => {
    const waveResults = await submitAthletePerformance(performance);
    setResults(waveResults);
    setStep(3);
  };

  const handleReset = () => {
    setAthleteInfo({
      fullName: '',
      club: '',
      email: '',
      bibNumber: ''
    });
    setPerformance({
      fullName: '',
      club: '',
      email: '',
      bibNumber: '',
      runningDistance: '5km',
      runningMinutes: 0,
      runningSeconds: 0,
      swimmingDistance: '400m',
      swimmingMinutes: 0,
      swimmingSeconds: 0,
      fitnessLevel: 3
    });
    setResults([]);
    setStep(1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 to-red-950">
      {step === 1 && (
        <BibNumberForm
          athleteInfo={athleteInfo}
          onAthleteInfoChange={setAthleteInfo}
          onSubmit={handleAthleteInfoSubmit}
        />
      )}
      {step === 2 && (
        <PerformanceForm
          performance={performance}
          onPerformanceChange={setPerformance}
          onSubmit={handlePerformanceSubmit}
        />
      )}
      {step === 3 && (
        <ResultsView
          results={results}
          athleteName={athleteInfo.fullName}
          onReset={handleReset}
        />
      )}
    </div>
  );
}