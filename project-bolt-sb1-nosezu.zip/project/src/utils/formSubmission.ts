interface AthleteFormData {
  firstName: string;
  lastName: string;
  club: string;
  email: string;
  swimTime: string; // Format: "4'32"
  swimPace: string; // Format: "2'15/100m"
  runPace: string; // Format: "5'30/km"
  completedWaves: number;
  fitnessLevel: number;
  performance: {
    runningDistance: string;
    runningTime: string; // Format: "25'30"
    swimmingDistance: string;
    swimmingTime: string; // Format: "4'32"
  };
}

const formatTimeToMinSec = (seconds: number): string => {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes}'${remainingSeconds.toString().padStart(2, '0')}`;
};

export const submitToNetlify = async (data: AthleteFormData): Promise<boolean> => {
  try {
    const formData = new FormData();
    
    // Add required Netlify form identification
    formData.append('form-name', 'athlete-data');
    
    // Add all fields to FormData
    Object.entries(data).forEach(([key, value]) => {
      if (typeof value === 'object') {
        // Handle nested performance object
        Object.entries(value).forEach(([nestedKey, nestedValue]) => {
          formData.append(`${key}_${nestedKey}`, nestedValue.toString());
        });
      } else {
        formData.append(key, value.toString());
      }
    });

    const response = await fetch('/', {
      method: 'POST',
      headers: { 'Accept': 'application/json' },
      body: formData
    });
    
    if (!response.ok) {
      console.error('Form submission failed:', response.status, response.statusText);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Form submission error:', error);
    return false;
  }
};