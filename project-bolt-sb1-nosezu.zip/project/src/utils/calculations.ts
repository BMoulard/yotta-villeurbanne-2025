import { WaveResult } from '../types';

// Constants for race configuration
const RACE_CONSTANTS = {
  TRANSITION_TIME: 30, // seconds
  WAVE_LENGTH: 25, // minutes
  SWIM_RACE_DISTANCE: 0.2, // 200m in km
  RUN_RACE_DISTANCE: 2, // 2km
  TIME_LIMITS: [25 * 60, 21 * 60, 17 * 60, 13 * 60, 13 * 60],
  WAVE_NAMES: ["Kilo", "Mega", "Giga", "Tera", "Peta"]
};

export const calculatePace = (distance: string, minutes: number, seconds: number) => {
  const totalSeconds = minutes * 60 + seconds;
  const distanceValue = parseFloat(distance.replace(/[^0-9.]/g, ''));
  
  // Convert to meters/kilometers for standardization
  const distanceInMeters = distance.includes('km') ? distanceValue * 1000 : distanceValue;
  
  return totalSeconds / (distanceInMeters / 1000); // seconds per km
};

export const formatPace = (secondsPerKm: number, isSwimming: boolean) => {
  if (isSwimming) {
    // Convert to 100m pace for swimming
    const secondsPer100m = secondsPerKm / 10;
    const minutes = Math.floor(secondsPer100m / 60);
    const seconds = Math.floor(secondsPer100m % 60);
    return `${minutes}'${seconds.toString().padStart(2, '0')}`;
  } else {
    // Format as per km pace for running
    const minutes = Math.floor(secondsPerKm / 60);
    const seconds = Math.floor(secondsPerKm % 60);
    return `${minutes}'${seconds.toString().padStart(2, '0')}`;
  }
};

const calculateDegradationFactor = (waveIndex: number, fitnessLevel: number): number => {
  return 1 + (waveIndex * (6 - fitnessLevel) * 0.007);
};

const calculateSegmentTime = (baseTime: number, degradationFactor: number): number => {
  return baseTime * degradationFactor;
};

export const calculateWaveResults = (
  swimPacePerKm: number,
  runPacePerKm: number,
  fitnessLevel: number
): WaveResult[] => {
  const waveInterval = RACE_CONSTANTS.WAVE_LENGTH * 60; // Convert minutes to seconds

  return RACE_CONSTANTS.TIME_LIMITS.map((timeLimit, index) => {
    const degradationFactor = calculateDegradationFactor(index, fitnessLevel);
    
    const swimming = calculateSegmentTime(
      swimPacePerKm * RACE_CONSTANTS.SWIM_RACE_DISTANCE,
      degradationFactor
    );
    const running = calculateSegmentTime(
      runPacePerKm * RACE_CONSTANTS.RUN_RACE_DISTANCE,
      degradationFactor
    );
    
    const baseTime = swimming + RACE_CONSTANTS.TRANSITION_TIME + running;
    const recovery = index < 4 ? Math.max(0, waveInterval - baseTime) : (waveInterval - baseTime);
    
    return {
      wave: index + 1,
      waveName: RACE_CONSTANTS.WAVE_NAMES[index],
      swimming,
      transition: RACE_CONSTANTS.TRANSITION_TIME,
      running,
      recovery,
      totalTime: baseTime,
      cutOffTime: timeLimit,
      swimPace: formatPace(swimPacePerKm, true),
      runPace: formatPace(runPacePerKm, false)
    };
  });
};