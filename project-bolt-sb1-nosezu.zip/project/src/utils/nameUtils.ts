export const extractNameParts = (fullName: string): { firstName: string; lastName: string } => {
  const [firstName, ...lastNameParts] = fullName.split(' ');
  const lastName = lastNameParts.join(' ');
  return { firstName, lastName };
};