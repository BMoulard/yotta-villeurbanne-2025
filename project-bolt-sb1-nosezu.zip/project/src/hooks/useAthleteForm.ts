import { useState } from 'react';
import { AthleteInfo, AthletePerformance, WaveResult } from '../types';

export function useAthleteForm() {
  const [step, setStep] = useState(1);
  const [athleteInfo, setAthleteInfo] = useState<AthleteInfo>({
    fullName: '',
    club: '',
    email: '',
    bibNumber: ''
  });
  const [performance, setPerformance] = useState<AthletePerformance>({
    ...athleteInfo,
    runningDistance: '5km',
    runningMinutes: 0,
    runningSeconds: 0,
    swimmingDistance: '400m',
    swimmingMinutes: 0,
    swimmingSeconds: 0,
    fitnessLevel: 3
  });
  const [results, setResults] = useState<WaveResult[]>([]);

  return {
    step,
    setStep,
    athleteInfo,
    setAthleteInfo,
    performance,
    setPerformance,
    results,
    setResults
  };
}